import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, RotateCcw, Trophy, Star, RefreshCw, Flame, Lock, User as UserIcon, Download, X, Settings, ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { all30Days, motivations21 } from './data';
import { toPng } from 'html-to-image';

interface AppState {
  currentDay: number; // 1-indexed
  completedTasks: Record<number, boolean[]>; // day -> [task1Done, task2Done]
  startDate: string;
  lastVisitDate: string;
  missedDays: number;
  hasSeenOnboarding: boolean;
}

const DEFAULT_STATE: AppState = {
  currentDay: 1,
  completedTasks: {},
  startDate: new Date().toISOString(),
  lastVisitDate: new Date().toISOString(),
  missedDays: 0,
  hasSeenOnboarding: false,
};

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('thriving_challenge_state');
    if (saved) return JSON.parse(saved);
    return DEFAULT_STATE;
  });

  const [viewDay, setViewDay] = useState<number | null>(null);
  const [motivationIndex, setMotivationIndex] = useState(0);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isReviewing, setIsReviewing] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);
  const [agreedToRules, setAgreedToRules] = useState(false);
  const milestoneRef = useRef<HTMLDivElement>(null);

  const maxUnlockedDay = useMemo(() => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const start = new Date(state.startDate);
    start.setHours(0, 0, 0, 0);
    const dayDiff = Math.floor((today.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    return Math.min(30, Math.max(1, dayDiff));
  }, [state.startDate]);

  // Check for missed days and auto-advance on load
  useEffect(() => {
    const advanceDayAtMidnight = () => {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const lastVisit = new Date(state.lastVisitDate);
      lastVisit.setHours(0, 0, 0, 0);

      const diffTime = today.getTime() - lastVisit.getTime();
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays > 0) {
        // We have passed at least one midnight since the last visit
        let newDay = state.currentDay;
        let lastDayEvaluated = state.currentDay;
        
        // Progression Rule: If at least one task was done of the current active day,
        // we can advance. Since we might have missed multiple days, we only advance 
        // ONE day if the tasks for the day they were on were completed.
        const tasksOfActiveDay = state.completedTasks[state.currentDay] || [false, false];
        const someTasksDone = tasksOfActiveDay.some(t => t);

        if (someTasksDone) {
          newDay = Math.min(30, state.currentDay + 1);
        }

        setState(prev => ({
          ...prev,
          currentDay: newDay,
          lastVisitDate: new Date().toISOString(),
          missedDays: someTasksDone ? 0 : prev.missedDays + diffDays 
        }));
        setIsReviewing(false);
      } else {
        // Just update last visit to keep it fresh
        setState(s => ({ ...s, lastVisitDate: new Date().toISOString() }));
      }
    };

    advanceDayAtMidnight();

    // Set a timer to trigger exactly at the next midnight
    const now = new Date();
    const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const msToMidnight = nextMidnight.getTime() - now.getTime();

    const timer = setTimeout(() => {
      advanceDayAtMidnight();
    }, msToMidnight + 100);

    return () => clearTimeout(timer);
  }, [state.startDate]); // Removed state.currentDay from deps to prevent loop

  // Sync to local storage on every state change
  useEffect(() => {
    localStorage.setItem('thriving_challenge_state', JSON.stringify(state));
  }, [state]);

  const totalTasks = 30 * 2;
  const completedTasksCount = (Object.values(state.completedTasks) as boolean[][]).reduce((acc, tasks) => {
    return acc + tasks.filter(Boolean).length;
  }, 0);

  const progressPercent = Math.round((completedTasksCount / totalTasks) * 100);

  const currentTasksDone = state.completedTasks[state.currentDay] || [false, false];
  const allTasksDoneToday = currentTasksDone[0] && currentTasksDone[1];

  // The day that should be shown by default (today, or tomorrow if today is done)
  const defaultFocusDay = allTasksDoneToday && state.currentDay < 30 ? state.currentDay + 1 : state.currentDay;
  
  // The day actually being viewed (either manually selected or the default)
  const activeFocusDay = viewDay || defaultFocusDay;
  
  // Is the day being viewed a "future" preview? 
  // It's a preview if:
  // 1. It's the automatic "next day" preview (activeFocusDay > state.currentDay)
  // 2. The user manually jumped to a future day (not possible with current calendar logic but safe to check)
  const isFuturePreview = activeFocusDay > state.currentDay;
  
  // Are we reviewing a past day?
  const isReviewMode = activeFocusDay < state.currentDay || (activeFocusDay === state.currentDay && allTasksDoneToday && viewDay === state.currentDay);

  const tasksForFocusDay = state.completedTasks[activeFocusDay] || [false, false];

  const toggleTask = (taskIndex: number) => {
    // ONLY allow toggling tasks for the actual current progress day
    // AND only if it's not a future preview
    if (activeFocusDay !== state.currentDay || isFuturePreview) return;

    const newTasks = [...currentTasksDone];
    newTasks[taskIndex] = !newTasks[taskIndex];

    const newState = {
      ...state,
      completedTasks: {
        ...state.completedTasks,
        [state.currentDay]: newTasks,
      },
      lastVisitDate: new Date().toISOString()
    };

    setState(newState);
  };

  const jumpToDay = (day: number) => {
    const isTodayDone = (state.completedTasks[state.currentDay] || [false, false]).every(t => t);
    const maxLinkable = isTodayDone ? state.currentDay + 1 : state.currentDay;
    
    if (day <= maxLinkable) {
      setViewDay(day);
      setIsCalendarOpen(false);
    }
  };

  const resetAllProgress = () => {
    if (resetConfirm) {
      const newState: AppState = {
        ...DEFAULT_STATE,
        startDate: new Date().toISOString(),
        lastVisitDate: new Date().toISOString(),
        hasSeenOnboarding: true // Keep onboarding seen even after reset
      };
      setState(newState);
      setIsReviewing(false);
      setResetConfirm(false);
      setIsProfileOpen(false);
    } else {
      setResetConfirm(true);
      setTimeout(() => setResetConfirm(false), 3000);
    }
  };

  const downloadMilestone = async () => {
    if (milestoneRef.current === null) return;
    try {
      const dataUrl = await toPng(milestoneRef.current, { cacheBust: true });
      const link = document.createElement('a');
      link.download = `30day-challenge-day-${state.currentDay}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Download failed', err);
    }
  };

  const nextMotivation = () => setMotivationIndex(prev => (prev + 1) % motivations21.length);
  const prevMotivation = () => setMotivationIndex(prev => (prev - 1 + motivations21.length) % motivations21.length);

  const activeDayIndex = activeFocusDay - 1;
  const activeDayData = all30Days[activeDayIndex] || all30Days[0];

  const handleFinishOnboarding = () => {
    if (agreedToRules) {
      setState(prev => ({ ...prev, hasSeenOnboarding: true }));
    }
  };

  return (
    <div className="min-h-screen bg-[#f0f4f8] text-slate-900 font-sans flex flex-col items-center overflow-x-hidden">
      {/* Onboarding Modal */}
      <AnimatePresence>
        {!state.hasSeenOnboarding && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white w-full max-w-lg rounded-[40px] shadow-2xl overflow-hidden p-8 md:p-10"
            >
              <div className="text-center space-y-6">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Star className="w-8 h-8 text-blue-600" />
                </div>
                
                <h2 className="text-2xl md:text-3xl font-black text-slate-800 leading-tight">
                  ৩০ দিনের সেলফ ইমপ্রুভমেন্ট (লেভেল - ইজি) চ্যালেঞ্জে আপনাকে স্বাগতম
                </h2>

                <div className="text-left bg-slate-50 p-6 rounded-3xl space-y-4 border border-slate-100">
                  <p className="font-black text-blue-600 uppercase tracking-widest text-xs">আপনার কাজ হলো:</p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-slate-600 font-medium">
                      <div className="w-5 h-5 rounded-full bg-blue-100 flex-shrink-0 flex items-center justify-center mt-0.5">
                        <div className="w-2 h-2 bg-blue-600 rounded-full" />
                      </div>
                      প্রতি দিন আপনাকে যে ২ টা টাস্ক দেওয়া হবে তা পূরণ করে চেকবক্সে ক্লিক করা।
                    </li>
                    <li className="flex items-start gap-3 text-slate-600 font-medium">
                      <div className="w-5 h-5 rounded-full bg-blue-100 flex-shrink-0 flex items-center justify-center mt-0.5">
                        <div className="w-2 h-2 bg-blue-600 rounded-full" />
                      </div>
                      প্রতি দিনের টাস্ক প্রতিদিন কমপ্লিট করা এবং কনসিস্টেন্ট থাকা।
                    </li>
                  </ul>
                </div>

                <label className="flex items-center gap-3 cursor-pointer group p-2 justify-center">
                  <div className="relative">
                    <input 
                      type="checkbox" 
                      className="peer sr-only"
                      checked={agreedToRules}
                      onChange={(e) => setAgreedToRules(e.target.checked)}
                    />
                    <div className="w-6 h-6 border-2 border-slate-200 rounded-lg bg-white peer-checked:bg-blue-600 peer-checked:border-blue-600 transition-all flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-white opacity-0 peer-checked:opacity-100 transition-opacity" />
                    </div>
                  </div>
                  <span className="text-slate-500 font-bold text-sm group-hover:text-slate-800 transition-colors">
                    আমি সব নিয়ম ঠিক ভাবে পড়েছি
                  </span>
                </label>

                <button 
                  onClick={handleFinishOnboarding}
                  disabled={!agreedToRules}
                  className={`w-full py-5 rounded-[24px] font-black text-lg transition-all shadow-xl ${
                    agreedToRules 
                      ? 'bg-blue-600 text-white shadow-blue-200 hover:bg-blue-700 active:scale-95' 
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Okay
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Top Header */}
      <header className="w-full bg-white shadow-sm border-b border-slate-100 p-4 mb-4 md:mb-8 flex justify-center sticky top-0 z-40">
        <div className="w-full max-w-4xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl">30</span>
            </div>
            <h1 className="text-xl font-bold text-slate-800 hidden sm:block">Challenge Tracker</h1>
          </div>
          
          <div className="flex items-center">
            <div className="flex items-center gap-2 bg-green-50 px-4 py-1.5 rounded-full border border-green-200/60 shadow-sm whitespace-nowrap">
              <Flame className="w-4 h-4 text-green-600 fill-green-500" />
              <span className="text-xs font-black text-green-800 uppercase tracking-tight">Streak: {state.currentDay} Days</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={() => {
                setViewDay(null);
                setIsProfileOpen(true);
              }}
              className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 border-2 border-slate-200 hover:border-blue-500 transition-all shadow-sm"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-6xl px-4 flex flex-col lg:flex-row items-center lg:items-start justify-center gap-6 md:gap-10 pb-20">
        {/* Main Challenge Card */}
        <div className="w-full max-w-md shrink-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeFocusDay + (isFuturePreview ? "_future" : "_active")}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className={`relative w-full min-h-[520px] card-gradient rounded-[40px] shadow-2xl p-8 flex flex-col justify-between overflow-hidden transition-all duration-500`}
            >
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-white opacity-5 rounded-full pointer-events-none"></div>
                
                <div className="z-10 text-center mb-6">
                  <div className="flex justify-center items-center gap-2 mb-2">
                    <Star className="w-4 h-4 text-blue-300" />
                    <span className="text-blue-300 uppercase tracking-[0.2em] font-bold text-xs">
                      {isFuturePreview 
                        ? "PREVIEW: TOMORROW" 
                        : isReviewMode 
                          ? "REVIEW MODE" 
                          : "GOAL OF THE DAY"}
                    </span>
                  </div>
                  <h2 className="text-white text-3xl font-black">DAY {activeFocusDay}</h2>
                </div>

                <div className="space-y-6 z-10 flex-grow py-4">
                  {activeDayData.tasks.map((task, idx) => {
                    const isDone = tasksForFocusDay[idx];
                    return (
                      <button
                        key={task.id}
                        onClick={() => toggleTask(idx)}
                        disabled={isFuturePreview || isReviewMode}
                        className={`w-full group relative flex flex-col items-start gap-2 p-6 rounded-3xl transition-all duration-300 text-left border-2 ${
                          isDone 
                            ? 'bg-blue-500/40 border-blue-300 text-white shadow-lg' 
                            : isFuturePreview || isReviewMode
                              ? 'bg-white/5 border-white/10 text-white/50 cursor-not-allowed opacity-60'
                              : 'glass-effect border-transparent text-white/90 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        <div className={`w-6 h-6 border-2 rounded-lg mb-2 flex items-center justify-center transition-all ${
                          isDone 
                            ? 'bg-white border-white' 
                            : 'border-white/30 bg-white/5'
                        }`}>
                          {isDone && <CheckCircle2 className="w-4 h-4 text-blue-500" />}
                          {(isFuturePreview || isReviewMode) && !isDone && <Lock className="w-3 h-3 text-white/20" />}
                        </div>
                        <p className="text-lg font-medium leading-relaxed">
                          {task.text}
                        </p>
                      </button>
                    );
                  })}
                </div>

                <div className="z-10 flex flex-col items-center gap-4 mt-6">
                  {isFuturePreview ? (
                    <div className="bg-white/10 px-6 py-2 rounded-full border border-white/20">
                      <span className="text-white/60 text-[10px] uppercase font-black tracking-widest flex items-center gap-2">
                         <Lock className="w-3 h-3 text-white/40" /> আজ এটুকুই! কাল রাত ১২টার পর খুলবে
                      </span>
                    </div>
                  ) : isReviewMode ? (
                    <div className="bg-white/10 px-6 py-2 rounded-full border border-white/20">
                      <span className="text-white/60 text-[10px] uppercase font-black tracking-widest flex items-center gap-2">
                         <Star className="w-3 h-3 text-blue-300" /> রিভিউ মোড: আপনার আগের অগ্রগতি
                      </span>
                    </div>
                  ) : (
                    <div className="bg-white/10 px-6 py-2 rounded-full border border-white/20">
                      <span className="text-white/40 text-[10px] uppercase font-black tracking-widest flex items-center gap-2">
                         <Star className="w-3 h-3" /> Day {activeFocusDay} In Progress
                      </span>
                    </div>
                  )}
                </div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="flex-1 w-full max-w-xl space-y-6 md:space-y-8">
          {/* Motivation Slider */}
          <div className="bg-white p-6 md:p-10 rounded-[32px] md:rounded-[40px] shadow-sm border border-slate-100 relative overflow-hidden h-[340px] md:h-[400px] flex flex-col justify-between group">
            <div className="absolute top-0 right-0 p-4">
              <Star className="w-8 h-8 text-blue-50 transition-transform group-hover:rotate-12" />
            </div>
            
            <div className="flex-1 relative mt-4">
              <AnimatePresence mode="wait">
                <motion.div
                  key={motivationIndex}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ type: "spring", damping: 20, stiffness: 100 }}
                  className="flex flex-col h-full"
                >
                  <p className="text-slate-400 text-[10px] uppercase font-black tracking-[0.3em] mb-6 flex items-center gap-2">
                    <span className="w-10 h-[2px] bg-blue-100"></span>
                    Wisdom {motivationIndex + 1}
                  </p>
                  <p className="text-slate-800 text-xl md:text-3xl leading-snug font-medium italic mb-10 overflow-auto">
                    "{motivations21[motivationIndex]}"
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-50">
              <p className="text-blue-600 font-black text-xs uppercase tracking-widest">
                Mindset Matters
              </p>
              <div className="flex gap-4">
                <button 
                  onClick={prevMotivation}
                  className="w-10 h-10 rounded-full hover:bg-blue-50 transition-all text-slate-300 hover:text-blue-600 flex items-center justify-center border border-transparent hover:border-blue-100"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button 
                  onClick={nextMotivation}
                  className="w-10 h-10 rounded-full hover:bg-blue-50 transition-all text-slate-300 hover:text-blue-600 flex items-center justify-center border border-transparent hover:border-blue-100"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Progress Section */}
          <div className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-50 space-y-6">
            <div className="flex justify-between items-end">
              <div>
                <h3 className="font-black text-slate-800 text-lg">Overall Progress</h3>
                <p className="text-slate-400 text-sm font-medium tracking-tight">Your 30-day transformation</p>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-4xl font-black text-blue-600 tabular-nums leading-none">{progressPercent}%</span>
                <span className="text-[10px] font-bold text-slate-300 uppercase mt-1">Completed</span>
              </div>
            </div>
            
            <div className="w-full h-5 bg-slate-100 rounded-full overflow-hidden p-1 shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                className="h-full bg-blue-600 rounded-full shadow-lg"
              />
            </div>
            <div className="flex justify-between items-center text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <span>Day 1</span>
              <span>{completedTasksCount} / {totalTasks} Tasks</span>
              <span>Day 30</span>
            </div>
          </div>
        </div>
      </main>

      {/* Persistent Bottom Calendar */}
      <section className="w-full max-w-4xl px-4 mt-8 mb-20 animate-in fade-in duration-700 delay-300 fill-mode-both">
        <div className="bg-white p-8 md:p-10 rounded-[40px] shadow-sm border border-slate-50">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-black text-slate-800">Your Journey</h3>
              <p className="text-slate-400 text-sm font-medium tracking-tight">Jump to any day to review tasks</p>
            </div>
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-blue-600" />
            </div>
          </div>

          <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-10 gap-3">
            {Array.from({ length: 30 }).map((_, i) => {
              const day = i + 1;
              const isCompleted = state.completedTasks[day] && state.completedTasks[day][0] && state.completedTasks[day][1];
              const isCurrent = state.currentDay === day;
              const hasSome = state.completedTasks[day] && (state.completedTasks[day][0] || state.completedTasks[day][1]);
              
              const isTodayDone = (state.completedTasks[state.currentDay] || [false, false]).every(t => t);
              const maxLinkable = isTodayDone ? state.currentDay + 1 : state.currentDay;
              const isLocked = day > maxLinkable;
              const isNextDayPreview = day === state.currentDay + 1 && isTodayDone;

              return (
                <button
                  key={day}
                  onClick={() => !isLocked && jumpToDay(day)}
                  disabled={isLocked}
                  className={`relative aspect-square rounded-2xl flex flex-col items-center justify-center transition-all active:scale-95 group ${
                    isLocked
                      ? 'bg-slate-100 text-slate-300 cursor-not-allowed opacity-60'
                      : isCurrent 
                        ? 'bg-blue-600 text-white shadow-lg ring-4 ring-blue-100 z-10' 
                        : isCompleted 
                          ? 'bg-green-50 text-green-600 border border-green-100 hover:bg-green-100' 
                          : isNextDayPreview
                            ? 'bg-amber-50 text-amber-600 border border-amber-100 animate-pulse'
                            : hasSome
                              ? 'bg-blue-50 text-blue-600 border border-blue-100 hover:bg-blue-100 shadow-sm'
                              : 'bg-slate-50 text-slate-400 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase opacity-60 mb-0.5">D</span>
                  {isLocked ? (
                    <Lock className="w-4 h-4" />
                  ) : (
                    <span className="text-lg font-black">{day}</span>
                  )}
                  {isCompleted && !isLocked && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white flex items-center justify-center shadow-sm">
                       <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                    </div>
                  )}
                  {isNextDayPreview && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full border-2 border-white flex items-center justify-center shadow-sm">
                       <Lock className="w-2 h-2 text-white" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Reset Section at the Bottom */}
      <section className="w-full max-w-4xl px-4 mt-4 mb-20 text-center">
        <button 
          onClick={resetAllProgress}
          className={`font-bold text-sm tracking-widest uppercase flex items-center gap-2 mx-auto transition-all active:scale-95 py-4 px-8 rounded-2xl ${
            resetConfirm 
              ? 'bg-red-500 text-white shadow-lg animate-pulse' 
              : 'text-slate-400 hover:text-red-500 hover:bg-red-50'
          }`}
        >
          <RotateCcw className={`w-4 h-4 ${resetConfirm ? 'animate-spin' : ''}`} />
          {resetConfirm ? "Click Again to Reset Everything" : "Reset All Progress"}
        </button>
      </section>

      {/* Settings Modal */}
      <AnimatePresence>
        {isProfileOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsProfileOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="relative bg-white w-full max-w-lg rounded-t-[40px] sm:rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-black text-slate-800">Challenge Tools</h3>
                  <button onClick={() => setIsProfileOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                    <X className="w-6 h-6 text-slate-400" />
                  </button>
                </div>

                <div className="flex items-center gap-6 mb-10 pb-10 border-b border-slate-50">
                  <div className="w-20 h-20 rounded-3xl bg-blue-50 flex items-center justify-center border-4 border-white shadow-lg">
                    <Trophy className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-slate-800">Active Challenge</h4>
                    <p className="text-slate-400 font-medium tracking-tight">Day {state.currentDay} in progress</p>
                    <div className="flex items-center gap-2 mt-2">
                       <span className="bg-blue-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter shadow-md">
                         Local Storage Enabled
                       </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h5 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Milestone Card</h5>
                    <button 
                      onClick={downloadMilestone}
                      className="w-full bg-blue-600 text-white py-5 rounded-[24px] font-black flex items-center justify-center gap-3 shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all active:scale-[0.98]"
                    >
                      <Download className="w-5 h-5" />
                      Download Milestone
                    </button>
                    <p className="text-center text-slate-400 text-xs mt-3">
                      Generate a card for your Day {state.currentDay} progress
                      {state.missedDays > 0 && <span className="block text-red-500 font-bold uppercase mt-1">Warning: {state.missedDays} days silent</span>}
                    </p>
                  </div>

                  <button 
                    onClick={resetAllProgress}
                    className={`w-full py-5 rounded-[24px] font-bold flex items-center justify-center gap-3 transition-all ${
                      resetConfirm 
                        ? 'bg-red-600 text-white shadow-lg' 
                        : 'bg-slate-50 text-slate-400 hover:bg-red-50 hover:text-red-500'
                    }`}
                  >
                    <RotateCcw className={`w-5 h-5 ${resetConfirm ? 'animate-spin' : ''}`} />
                    {resetConfirm ? "Tap Again to Confirm" : "Reset Challenge"}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Hidden Milestone Card Template for Download */}
      <div className="fixed -left-[2000px] top-0 pointer-events-none">
        <div 
          ref={milestoneRef}
          className="w-[800px] h-[1000px] bg-gradient-to-br from-blue-700 to-indigo-900 p-16 flex flex-col justify-between items-center text-center text-white"
        >
          <div className="space-y-4">
             <div className="w-32 h-32 bg-white/10 rounded-3xl mx-auto flex items-center justify-center border-4 border-blue-400">
               <span className="text-white font-black text-6xl italic">30</span>
             </div>
             <p className="text-blue-200 text-xl font-black uppercase tracking-[0.4em]">30 Days Challenge</p>
          </div>

          <div className="space-y-8">
            <h1 className="text-8xl font-black leading-none uppercase">DAY {state.currentDay}</h1>
            <div className="h-2 w-40 bg-blue-400 mx-auto rounded-full"></div>
            <p className="text-4xl font-medium italic text-blue-100 max-w-2xl">
              "আমি পারছি এবং আমি শেষ পর্যন্ত করবো।"
            </p>
          </div>

          <div className="w-full space-y-10">
            <div className="flex flex-col items-center gap-4">
              <div className="w-full h-6 bg-white/10 rounded-full overflow-hidden p-1 border-2 border-white/20">
                <div 
                  className="h-full bg-white rounded-full" 
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
              <p className="text-2xl font-black uppercase tracking-widest text-blue-200">
                Overall Progress: {progressPercent}%
              </p>
            </div>
            
            <div className="flex justify-between items-center pt-10 border-t border-white/10">
              <div className="text-left">
                <p className="text-blue-300 font-bold uppercase tracking-widest">Progress</p>
                <p className="text-2xl font-black uppercase">Consistently Rising</p>
              </div>
              <div className="text-right">
                <p className="text-blue-300 font-bold uppercase tracking-widest">Streak</p>
                <p className="text-2xl font-black uppercase">{state.currentDay} Days</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="w-full bg-slate-900 py-12 px-4 text-center mt-auto">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center">
            <CheckCircle2 className="w-4 h-4 text-white" />
          </div>
          <p className="text-white font-black tracking-widest text-lg uppercase">30 Days Challenge</p>
        </div>
        <p className="text-slate-500 text-sm font-medium">
          © 2024 Productivity Hub • Stay Consistent • No Login Required
        </p>
      </footer>
    </div>
  );
}
